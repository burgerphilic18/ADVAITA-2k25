import React from 'react';
import SponsorsPage from './SponsorsPage';
import Gallery from './Gallery';

function App() {
  return (
    <div className="App">
      <Gallery />
      <SponsorsPage />
      
    </div>
  );
}

export default App;