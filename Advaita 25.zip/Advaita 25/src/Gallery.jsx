import React from 'react';
import './Gallery.css';

const Gallery = () => {
  return (
    <div className="gallery-container">
      {/* Header with logo and banners */}
      <header className="gallery-header">
        <div className="logo-container">
          <div className="logo-diamond"></div>
          <h1 className="gallery-title">Gallery</h1>
        </div>
        <div className="banners">
          <div className="banner red"></div>
          <div className="banner yellow"></div>
          <div className="banner blue"></div>
          <div className="banner green"></div>
        </div>
      </header>

      {/* Main gallery grid */}
      <div className="gallery-grid">
        {/* Left tall image */}
        <div className="gallery-item tall-left">
          <img src="/api/placeholder/320/400" alt="Gallery image" />
        </div>
        
        {/* Top center image */}
        <div className="gallery-item center-top">
          <img src="/api/placeholder/400/200" alt="Gallery image" />
        </div>
        
        {/* Right small image */}
        <div className="gallery-item small-right">
          <img src="/api/placeholder/200/200" alt="Gallery image" />
        </div>
        
        {/* Bottom wide image */}
        <div className="gallery-item wide-bottom">
          <img src="/api/placeholder/600/120" alt="Gallery image" />
        </div>
        
        {/* Full width image at bottom */}
        <div className="gallery-item full-width">
          <img src="/api/placeholder/1000/120" alt="Gallery image" />
        </div>
      </div>

      {/* Footer with buttons */}
      <div className="gallery-footer">
        <button className="gallery-button view-more">VIEW MORE</button>
        <button className="gallery-button brochure">BROCHURE</button>
      </div>
    </div>
  );
};

export default Gallery;